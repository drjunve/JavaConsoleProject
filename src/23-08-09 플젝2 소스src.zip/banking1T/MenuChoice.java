package banking1T;

public interface MenuChoice {
	
	//1.개설, 2.입금, 3.출금, 4.정보출력, 5.종료
	int MAKE = 1, DEPOSIT = 2, WITHDRAW = 3, INQUIRE = 4, EXIT = 5; 
			
}
